package Buoi4;

public class Bo extends ConVat{
	public Bo(String Giong,String MauLong,double CanNang) {
		super(Giong,MauLong,CanNang);
	}
	public void Keu() {
		System.out.println("Bo");
		super.Keu();
	}
}
