package Buoi4;

public class De extends ConVat{
	public De(String Giong,String MauLong,double CanNang) {
		super(Giong,MauLong,CanNang);
	}
	public void Keu() {
		System.out.println("De");
		super.Keu();
	}
}
